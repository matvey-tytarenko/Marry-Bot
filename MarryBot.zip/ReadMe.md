# Marry Telegram Bot
## What is this?
````
 it's your virtual girlfriend with Chat GPT in the telegram!
````

![](hello_picture.jpg)
___
# How To Run
[Start Bot in yours telegram](https://t.me/maryna21223233_bot)